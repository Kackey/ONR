======================================================================
SepPDF Ver2.77

  You can split PDF file containing multiple pages into individualized
  single PDF files for each page.
  If you want to split PDF file, drag & drop it and push "Split(All)" 
  button.
  You can also select the page range you wish to split.
  Some PDF files with security can be splitted.
  This PDF File Splitter can also start from ComPDF, and you can control
  screen indication then.
  SepPDF is Freeware.

   *ComPDF ...  Merge PDF files, Extract pages from PDF file, Give 
                security to PDF files.
   *While you operate SepPDF, a PDF file viewer program is unnecessary,
    but you need a PDF file viewer (Adobe Reader etc) in order to 
    confirm the results.
   *If you start SepPDF from ComPDF, Use more than ComPDF Version 1.071
    in order to use all functions.

                                      November 20, 2015   ForestH
======================================================================

[Confirmed OS]
WindowsXP(JP),WindowsVista(JP),Windows7(JP),Windows8(JP,US)

*Use old version(Ver.2.26) for Windows95,98,Me,NT,2000.

[Installation]
Unzip the file, and put all files in the same folder.
A free name can be given to the folder.

[Uninstallation]
Delete the folder where you installed these files in installation.
This software does not use Windows' registry at all.

[Histry of update]
Ver2.77 (November 20, 2015)
  Fixed some bugs.
Ver2.76 (October 23, 2015)
  Modify the message during operation.
Ver2.75 (September 18, 2015)
  Modify the message during operation.
Ver2.74 (August 21, 2015)
  Modify the message during operation.
Ver2.73 (July 17, 2015)
  Modify the message during operation.
Ver2.72 (June 19, 2015)
  The bug which may fail in writing of split file is corrected.
Ver2.71 (May 22, 2015)
  The bug which may fail in writing of split file is corrected.
Ver2.70 (April 17, 2015)
  The bug which may fail in writing of split file is corrected.
Ver2.69 (March 20, 2015)
  Bugs to fail in analysis of some files were revised.
Ver2.68 (February 20, 2015)
  Modify the message during operation.
Ver2.67 (January 23, 2015)
  The bug which may fail in reading of some file is corrected.
Ver2.66 (December 19, 2014)
  Fixed some bugs related to memory management.
Ver2.65 (November 21, 2014)
  Fixed some bugs related to memory management.
Ver2.64 (October 17, 2014)
  Fixed a redundant part of this program.
Ver2.63 (September 19, 2014)
  Fixed some bugs related to memory management.
Ver2.62 (August 22, 2014)
  Fixed some bugs.
Ver2.61 (July 18, 2014)
  Fixed some bugs.
Ver2.60 (June 20, 2014)
  Fixed some bugs.
Ver2.59 (May 23, 2014)
  Fixed a bug that may fail to read some files.
Ver2.58 (April 18, 2014)
  Improved command line reading part.
Ver2.57 (March 20, 2014)
  Fixed a bug that may fail to read the command line.
Ver2.56 (February 21, 2014)
  Fixed some bugs.
Ver2.55 (January 17, 2014)
  Fixed some bugs.
Ver2.54 (December 20, 2013)
  Fixed some bugs.
Ver2.53 (November 22, 2013)
  Fixed some bugs.
Ver2.52 (October 18, 2013)
  Fixed some bugs.
Ver2.51 (September 20, 2013)
  Fixed some bugs.
Ver2.50 (August 23, 2013)
  Changing the development environment, it has been significantly modified.
Ver2.26 (July 19, 2013)
  Fixed a redundant part of this program.
Ver2.25 (June 21, 2013)
  Fixed a redundant part of this program.
Ver2.24 (May 17, 2013)
  Fixed a redundant part of this program.
Ver2.23 (April 19, 2013)
  Fixed a redundant part of this program.
Ver2.22 (March 22, 2013)
  Bugs to fail in analysis of some files were revised.
Ver2.21 (February 22, 2013)
  Display number of pages has been fixed.
Ver2.20 (January 18, 2013)
  When a particular file processing was interrupted,
  the response time was reduced.
Ver2.19 (December 21, 2012)
  Fixed some bugs related to memory management.
Ver2.18 (November 22, 2012)
  Fixed some bugs related to memory management.
Ver2.17 (October 19, 2012)
  Fixed some bugs related to memory management.
Ver2.16 (September 21, 2012)
  Fixed a redundant part of this program.
Ver2.15 (August 24, 2012)
  Fixed a bug that temporary files may be removed when you save.
Ver2.14 (July 20, 2012)
  Fixed a bug that error may be not displayed when files are saved.
Ver2.13 (June 22, 2012)
  Bugs to fail in analysis of some files were revised.
Ver2.12 (May 18, 2012)
  Bugs to fail in analysis of some files were revised.
Ver2.11 (April 20, 2012)
  Fixed a redundant part of this program.
Ver2.10 (March 23, 2012)
  Modify the message during operation.
Ver2.09 (February 17, 2012)
  Modified to hold the input password.
Ver2.08 (January 20, 2012)
  Fixed bugs that caused error when specific procedure.
Ver2.07 (December 22, 2011)
  Fixed bugs that caused error when specific procedure.
Ver2.06 (November 18, 2011)
  Modify the message during operation.
Ver2.05 (October 21, 2011)
  Bugs to fail in analysis of some files were revised.
Ver2.04 (September 22, 2011)
  Some files with particular security can be splitted.
Ver2.03 (August 23, 2011)
  Fixed a bug that generated wrong file date.
Ver2.02 (July 15, 2011)
  Bugs to fail in analysis of some files were revised.
Ver2.01 (June 17, 2011)
  Bugs to fail in analysis of some files were revised.
Ver2.00 (May 20, 2011)
  Bugs to fail in analysis of some files were revised.
Ver1.99 (April 22, 2011)
  Some files with particular security can be splitted.
Ver1.98 (March 18, 2011)
  Bugs to fail in analysis of some files were revised.
Ver1.97 (February 18, 2011)
  Some files with particular security can be splitted.
Ver1.96 (January 21, 2011)
  Bugs to fail in analysis of some files were revised.
Ver1.95 (December 17, 2010)
  Bugs to fail in analysis of some files were revised.
Ver1.94 (November 19, 2010)
  Bugs to fail in analysis of some files were revised.
Ver1.93 (October 22, 2010)
  English documents were attached. etc.
Ver1.92 (September 17, 2010)
  Bugs to fail in analysis of some files were revised.
       (...)
Ver0.8  (January 10, 2002)
  This software was shown in ForestH's Homepage.
�@�@http://www.ne.jp/asahi/foresth/home/indexe.htm
